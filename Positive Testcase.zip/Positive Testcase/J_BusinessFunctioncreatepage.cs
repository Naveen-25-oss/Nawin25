﻿using ContinuityPatrol.AutomationTests.Extension;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;




namespace ContinuityPatrol.AutomationTests.Pages
{
    public class J_BusinessFunctioncreatepage : BasePage
    {
        private readonly IWebDriver _driver;

        #region Fields

        public IWebElement BusinessFunctionCreateButton => _driver.FindElement(By.Id("btnCreate"));

        [FindsBy(How = How.ClassName, Using = "body-header-text")]
        [CacheLookup]
        public IWebElement BusinessFunctionCreateFrame { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='stepper1']/div[1]/div/div[1]/span/span[2]")]
        [CacheLookup]
        public IWebElement BusinessDetailsPage { get; set; }

        public IWebElement BusinessFunctionName => _driver.FindElement(By.Id("txtName"));

        public IWebElement Description => _driver.FindElement(By.Id("txtDescription"));

        public IWebElement SelectBusinessService => _driver.FindElement(By.XPath("//*[@id='ddbusinessServiceId']"));

        public IWebElement BusinessServiceLabel => _driver.FindElement(By.XPath("//*[@id='ddbusinessServiceId']"));

        public IWebElement SelectCriticalLevel => _driver.FindElement(By.XPath("//*[@id='ddcriticalityLevel']"));

        public IWebElement CriticalLevelLabel => _driver.FindElement(By.XPath("//*[@id='ddcriticalityLevel']"));

        [FindsBy(How = How.XPath, Using = "//*[@id='btnNext']")]

        public IWebElement BusinessFunctionNextForwardButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='stepper1']/div[1]/div/div[3]/span/span[2]")]
        [CacheLookup]
        public IWebElement RecoveryObjectivesPage { get; set; }

        public IWebElement ConfigureRPO => _driver.FindElement(By.Id("txtConfiguredRPO"));

        public IWebElement ConfigureRTO => _driver.FindElement(By.Id("txtConfiguredRTO"));

        public IWebElement ConfigureMAO => _driver.FindElement(By.Id("txtConfiguredMAO"));

        [FindsBy(How = How.Id, Using = "btnPrev")]

        public IWebElement BusinessFunctionNextBackwardButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        [CacheLookup]
        public IWebElement BusinessFunctionCancelButton { get; set; }

        //[FindsBy(How = How.Id, Using = "btnSave")]
        //[CacheLookup]
        public IWebElement BusinessFunctionSaveButton => _driver.FindElement(By.Id("btnSave"));

        public IWebElement CreateClose => _driver.FindElement(By.Id("btnCloseModal"));

        [FindsBy(How = How.XPath, Using = "//*[@id='nila-toastr']")]
        public IWebElement BusinessFunctionSavePopUp { get; set; }

        [FindsBy(How = How.Id, Using = "txtthresholdRPO")]
        public IWebElement thresholdrpo { get; set; }

        #endregion

        #region Methods

        public string BusinessFunctionNameEnter
        {
            set => BusinessFunctionName.EnterText(value);
        }

        public string DescriptionEnter
        {
            set => Description.EnterText(value);
        }

        public void SelectBusinessServiceEnter(string businessService)

        {
            BusinessServiceLabel.Click();
            Wait(500);
            SelectBusinessService.SendKeys(businessService);
            SelectBusinessService.SendKeys(Keys.Enter);
        }

        public void SelectCriticalLevelEnter(string criticalLevel)

        {
            CriticalLevelLabel.Click();
            Wait(500);
            SelectCriticalLevel.SendKeys(criticalLevel);
            SelectCriticalLevel.SendKeys(Keys.Enter);
        }
        public string ConfigureRPOEnter
        {
            set => ConfigureRPO.EnterText(value);
        }
        public string ConfigureRTOEnter
        {
            set => ConfigureRTO.EnterText(value);
        }
        public string ConfigureMAOEnter
        {
            set => ConfigureMAO.EnterText(value);
        }

        public string BusinessFunctionThresholdRpo
        {
            set => thresholdrpo.EnterText(value);
        }



        private static Random random1 = new Random();
        public string RandomString(int len)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz _0123456789";
            return new string(Enumerable.Repeat(chars, len)
              .Select(s => s[random1.Next(64)]).ToArray());
        }

        public J_BusinessFunctioncreatepage(IWebDriver driver) : base(driver)
        {
            _driver = driver;

            PageFactory.InitElements(_driver, this);
        }

        public static J_BusinessFunctioncreatepage GoTo(IWebDriver driver)
        {
            driver.Navigate().GoToUrl(ConfigHelper.ApplicationPath + "configure/business_function");

            return new J_BusinessFunctioncreatepage(driver);
        }

        public J_BusinessFunctioncreatepage CreateBusinessDetails(string randomString1, string randomString2, string businessService, string criticalLevel)
        {
            BusinessFunctionNameEnter = randomString1;
            DescriptionEnter = randomString2;
            SelectBusinessServiceEnter(businessService);
            SelectCriticalLevelEnter(criticalLevel);
            return new J_BusinessFunctioncreatepage(_driver);

        }


        public J_BusinessFunctioncreatepage CreateRecoveryObjectives(string randomString5, string randomString6, string randomString7)
        {
            ConfigureRPOEnter = randomString5;
            ConfigureRTOEnter = randomString6;
            ConfigureMAOEnter = randomString7;

            return new J_BusinessFunctioncreatepage(_driver);
        }
        public void OpenCreateBusinessFunction()
        {
            BusinessFunctionCreateButton.Click();
        }
        public void CreateCloseFunction()
        {
            CreateClose.Click();
        }
        public void NextForwardBusinessFunction()
        {
            BusinessFunctionNextForwardButton.Click();
        }

        public void NextBackwardBusinessFunction()
        {
            BusinessFunctionNextBackwardButton.Click();
        }
        public void SaveBusinessFunction()
        {
            BusinessFunctionSaveButton.Click();
        }
        public void CancelBusinessFunction()
        {
            BusinessFunctionCancelButton.Click();
        }
        public void CloseCurrentWindow()
        {
            Driver.Instance.Close();
        }

        #endregion



        public bool CheckActivePage()

        {
            bool ActivePage = Driver.Instance.HasElement(By.XPath("//*[@id='btnSave']"));

            return ActivePage;
        }

        public override bool IsAt()
        {

            bool result = Driver.Instance.HasElement(By.XPath("//*[@id='createBusinessFunctionForm']"));
            return result;
        }
        public bool IsAtBuinessDetails()
        {
            var element = Driver.Instance.FindElement(By.XPath("//*[@id='stepper1']/div[1]/div/div[1]"));

            if (element != null)
            {
                return element.GetAttribute("class").ToLower().Contains("step active");
            }

            return false;
        }
    }
}























































