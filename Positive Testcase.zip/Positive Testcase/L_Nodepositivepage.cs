﻿


using ContinuityPatrol.AutomationTests.Extension;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;




namespace ContinuityPatrol.AutomationTests.Pages
{
    public class L_Nodepositivepage : BasePage
    {
        private readonly IWebDriver _driver;


        #region Node Details Fields

        public IWebElement NodeCreateButton => _driver.FindElement(By.XPath("//*[@id='layout-wrapper']/div[4]/div/div/div/div/div[1]/div/button"));

        public IWebElement NodeName => _driver.FindElement(By.Id("txtName"));

        public IWebElement CheckMaster => _driver.FindElement(By.Id("chkdatabaseAuthentication"));

        public IWebElement SelectServer => _driver.FindElement(By.XPath("//input[@id='ddserverId']"));

        public IWebElement ServerLabel => _driver.FindElement(By.XPath("//input[@id='ddserverId']"));

        public IWebElement OracleSID => _driver.FindElement(By.Id("txtDracleSID"));

        public IWebElement InstanceName => _driver.FindElement(By.Id("txtInstanceName"));

        public IWebElement Username => _driver.FindElement(By.Id("txtUserName"));

        public IWebElement Password => _driver.FindElement(By.Id("txtPassword"));

        public IWebElement Port => _driver.FindElement(By.Id("txtPort"));
        #endregion

        #region NodeConfiguration Fields

        public IWebElement SourceArchieveLogPath => _driver.FindElement(By.Id("txtsourceArchieveLogPath"));

        public IWebElement TargetArchieveLogPath => _driver.FindElement(By.Id("txttargetArchieveLogPath"));

        public IWebElement HomePath => _driver.FindElement(By.Id("txthome"));

        public IWebElement RedoPath => _driver.FindElement(By.Id("txtredo"));

        public IWebElement ChangeGroup => _driver.FindElement(By.Id("txtchangeGroupUser"));

        #endregion

        #region ASMAuthentication Fields

        public IWebElement CheckASMGrid => _driver.FindElement(By.Id("chkAD"));

        public IWebElement ASMInstancename => _driver.FindElement(By.Id("txtasmInstanceName"));

        public IWebElement ASMUSername => _driver.FindElement(By.Id("txtasmUserName"));

        public IWebElement ASMPassword => _driver.FindElement(By.Id("txtasmPassword"));

        public IWebElement ASMGridPath => _driver.FindElement(By.Id("txtasmGridPath"));

        public IWebElement CheckVariableBox => _driver.FindElement(By.XPath("//input[@id='chkenvVariable']"));

        public IWebElement EnvVariableName => _driver.FindElement(By.Id("txtenvVariableName"));

        public IWebElement CheckDBBAuthentication => _driver.FindElement(By.XPath("//input[@id='chkdatabaseAuthentication']"));

        public IWebElement SQLPLUS => _driver.FindElement(By.XPath("//input[@id='ddsqlPlus']"));

        public IWebElement SQLPLUSLabel => _driver.FindElement(By.XPath("//input[@id='ddsqlPlus']"));

        public IWebElement Authentication => _driver.FindElement(By.XPath("//input[@id='ddauthentication']"));

        public IWebElement AuthenticationLabel => _driver.FindElement(By.XPath("//input[@id='ddauthentication']"));

        public IWebElement Role => _driver.FindElement(By.XPath("//input[@id='ddrole']"));

        public IWebElement RoleLabel => _driver.FindElement(By.XPath("//input[@id='ddrole']"));





        #endregion

        #region Pages


        [FindsBy(How = How.XPath, Using = "//div[@id='stepper1']/div[1]/div/div[1]/span/span[2]")]
        [CacheLookup]
        public IWebElement NodeDetailsPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='stepper1']/div[1]/div/div[3]/span/span[2]")]
        [CacheLookup]

        public IWebElement NodeConfigurationPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='stepper1']/div[1]/div/div[5]/span/span[2]")]
        [CacheLookup]

        public IWebElement ASMAuthenticationPage { get; set; }

        #endregion

        #region Button

        public IWebElement NodeNextButton => _driver.FindElement(By.Id("btnNext"));

        [FindsBy(How = How.Id, Using = "btnPrev")]

        public IWebElement NodePreviousButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        [CacheLookup]
        public IWebElement NodeCancelButton { get; set; }

        //[FindsBy(How = How.Id, Using = "btnSave")]
        //[CacheLookup]
        public IWebElement NodeSaveButton => _driver.FindElement(By.Id("btnSave"));


        public IWebElement NodeCreateClose => _driver.FindElement(By.Id("btnCloseModal"));

        #endregion

        [FindsBy(How = How.XPath, Using = "//*[@id='nila-toastr']")]
        public IWebElement NodeSavePopUp { get; set; }

        

      


        #region xpath

        public string NodeNameClass => NodeName.GetAttribute("class");
        public string SelectServerClass => SelectServer.GetAttribute("value");
        public string OracleSIDClass => OracleSID.GetAttribute("class");
        public string InstanceNameClass => InstanceName.GetAttribute("class");
        public string UsernameClass => Username.GetAttribute("class");
        public string PasswordClass => Password.GetAttribute("class");
        public string PortNumClass => Port.GetAttribute("class");
        public string SourcePathClass => SourceArchieveLogPath.GetAttribute("class");
        public string TargetPathClass => TargetArchieveLogPath.GetAttribute("class");
        public string HomePathClass => HomePath.GetAttribute("class");
        public string RedoPathClass => RedoPath.GetAttribute("class");
        public string ChangeGroupClass => ChangeGroup.GetAttribute("class");
        public string ASMInstanceNameClass => ASMInstancename.GetAttribute("class");
        public string ASMUSernameClass => ASMUSername.GetAttribute("class");
        public string ASMPasswordClass => ASMPassword.GetAttribute("class");
        public string ASMGridPathClass => ASMGridPath.GetAttribute("class");
        public string EnvVariableNameClass => EnvVariableName.GetAttribute("class");
        public string SQLPLUSClass => SQLPLUS.GetAttribute("class");
        public string AuthenticationClass => Authentication.GetAttribute("class");
        public string RoleClass => Role.GetAttribute("class");

        #endregion

        #region Methods

        public string NodeNameEnter
        {
            set => NodeName.EnterText(value);
        }

        public void SelectServerEnter(string server)

        {
            ServerLabel.Click();
            Wait(500);
            SelectServer.SendKeys(server);
            SelectServer.SendKeys(Keys.Enter);
        }

        public string OracleSIDEnter
        {
            set => OracleSID.EnterText(value);
        }
        public string InstanceNameEnter
        {
            set => InstanceName.EnterText(value);
        }
        public string UsernameEnter
        {
            set => Username.EnterText(value);
        }

        public string PasswordEnter
        {
            set => Password.EnterText(value);
        }

        public string PortNumEnter
        {
            set => Port.EnterText(value);
        }

        public string SourcePathEnter
        {
            set => SourceArchieveLogPath.EnterText(value);
        }

        public string TargetPathEnter
        {
            set => TargetArchieveLogPath.EnterText(value);
        }

        public string HomePathEnter
        {
            set => HomePath.EnterText(value);
        }

        public string RedoPathEnter
        {
            set => RedoPath.EnterText(value);
        }

        public string ChangeGroupEnter
        {
            set => ChangeGroup.EnterText(value);
        }

        public string ASMInstancenameEnter
        {
            set => ASMInstancename.EnterText(value);
        }
        public string ASMUsernameEnter
        {
            set => ASMUSername.EnterText(value);
        }

        public string ASMPasswordEnter
        {
            set => ASMPassword.EnterText(value);
        }

        public string ASMGridPathEnter
        {
            set => ASMGridPath.EnterText(value);
        }

        public string EnvVariableNameEnter
        {
            set => EnvVariableName.EnterText(value);
        }

        public void SQLPLUSEnter(string sqlplus)

        {
            SQLPLUSLabel.Click();
            Wait(500);
            SQLPLUS.SendKeys(sqlplus);
            SQLPLUS.SendKeys(Keys.Enter);
        }

        public void AuthenticationEnter(string authentication)

        {
            AuthenticationLabel.Click();
            Wait(500);
            Authentication.SendKeys(authentication);
            Authentication.SendKeys(Keys.Enter);
        }

        public void RoleEnter(string role)

        {
            RoleLabel.Click();
            Wait(500);
            Role.SendKeys(role);
            Role.SendKeys(Keys.Enter);
        }
        private static Random random1 = new Random();
        public string RandomString(int len)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz _0123456789";
            return new string(Enumerable.Repeat(chars, len)
              .Select(s => s[random1.Next(64)]).ToArray());
        }



        public L_Nodepositivepage(IWebDriver driver) : base(driver)
        {
            _driver = driver;

            PageFactory.InitElements(_driver, this);

        }


        public static L_Nodepositivepage GoTo(IWebDriver driver)
        {
            driver.Navigate().GoToUrl(ConfigHelper.ApplicationPath + "configure/node");

            return new L_Nodepositivepage(driver);
        }

        public L_Nodepositivepage CreateNodeDetails(string randomString1, string server, string randomString2, string randomString3, string randomString4, string randomString5, string randomString6)
        {


            NodeNameEnter = randomString1;
            SelectServerEnter(server);
            OracleSIDEnter = randomString2;
            InstanceNameEnter = randomString3;
            UsernameEnter = randomString4;
            PasswordEnter = randomString5;
            PortNumEnter = randomString6;

            return new L_Nodepositivepage(_driver);


        }



        public L_Nodepositivepage CreateNodeConfiguration(string randomString7, string randomString8, string randomString9, string randomstring10, string randomstring11)
        {
            SourcePathEnter = randomString7;
            TargetPathEnter = randomString8;
            HomePathEnter = randomString9;
            RedoPathEnter = randomstring10;
            ChangeGroupEnter = randomstring11;

            return new L_Nodepositivepage(_driver);
        }

        public void MasterCheckbox()
        {
            CheckMaster.HoverAndClick();
        }

        public void ASMGridCheckbox()
        {
            CheckASMGrid.HoverAndClick();
        }

        public void EnvVariableNameCheckbox()
        {
            CheckVariableBox.HoverAndClick();
        }

        public void DBAuthenticationCheckbox()
        {
            CheckDBBAuthentication.HoverAndClick();
        }
        public void OpenCreateNode()
        {
            NodeCreateButton.Click();
        }

        public void CreateCloseNode()
        {
            NodeCreateClose.Click();
        }
        public void NextForwardNode()
        {
            NodeNextButton.Click();
        }

        public void NextBackwardNode()
        {
            NodePreviousButton.Click();
        }
        public void SaveNode()
        {
            NodeSaveButton.Click();
        }

        public void CancelNode()
        {
            NodeCancelButton.Click();
        }

        public void CloseCurrentWindow()
        {
            Driver.Instance.Close();
        }

        public void AllClearNodeDetails()
        {
            NodeName.Clear();
            OracleSID.Clear();
            InstanceName.Clear();
            Username.Clear();
            Password.Clear();
            Port.Clear();
        }
        #endregion

      
        public override bool IsAt()
        {

            bool result = Driver.Instance.HasElement(By.XPath("//*[@id='layout-wrapper']/div[4]/div/div/div/div/div[1]/h6/span"));
            return result;


        }
        public bool IsAtNodeDetails()
        {
            var element = Driver.Instance.FindElement(By.XPath("//*[@id='stepper1']/div[1]/div/div[1]"));

            if (element != null)
            {
                return element.GetAttribute("class").ToLower().Contains("step active");
            }

            return false;


        }



    }

}























































