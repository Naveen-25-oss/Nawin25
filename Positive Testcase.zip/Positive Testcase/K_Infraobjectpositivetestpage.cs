﻿
using ContinuityPatrol.AutomationTests.Extension;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;


namespace ContinuityPatrol.AutomationTests.Pages
{
    public class K_Infraobjectpositivetestpage : BasePage
    {
        private readonly IWebDriver _driver;
        #region Fields

        [FindsBy(How = How.XPath, Using = "//*[@id=\"layout-wrapper\"]/div[4]/div/div/div/div/div[1]/div/button")]
        [CacheLookup]
        public IWebElement InfraObjectCreateButton { get; set; }

        [FindsBy(How = How.Id, Using = "myLargeModalLabel")]
        public IWebElement InfraObjectCreateFrame { get; set; }

        [FindsBy(How = How.Id, Using = "txtName")]
        [CacheLookup]
        public IWebElement InfraObjectName { get; set; }

        [FindsBy(How = How.Id, Using = "txtDescription")]
        [CacheLookup]
        public IWebElement DescriptionName { get; set; }


        [FindsBy(How = How.Id, Using = "div_businessServiceName")]
        [CacheLookup]
        public IWebElement BusinessServiceLabel { get; set; }

        [FindsBy(How = How.Id, Using = "ddbusinessServiceName")]
        [CacheLookup]
        public IWebElement BusinessServiceDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "div_businessFunctionName")]
        [CacheLookup]
        public IWebElement BusinessFunctionLabel { get; set; }



        [FindsBy(How = How.Id, Using = "ddbusinessFunctionName")]
        [CacheLookup]
        public IWebElement BusinessFunctionDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "div_ActivityType")]
        [CacheLookup]
        public IWebElement ActivityLabel { get; set; }

        [FindsBy(How = How.Id, Using = "ddsubType")]
        [CacheLookup]
        public IWebElement Subtype { get; set; }



        [FindsBy(How = How.XPath, Using = "//*[@id='ddActitytype']")]
        [CacheLookup]
        public IWebElement ActivityTypeDropdown { get; set; }


        [FindsBy(How = How.Id, Using = "div_replicationType")]
        [CacheLookup]
        public IWebElement ReplicationTypeLabel { get; set; }



        [FindsBy(How = How.Id, Using = "ddreplicationType")]
        [CacheLookup]
        public IWebElement ReplicationTypeDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "div_replicationName")]
        [CacheLookup]
        public IWebElement ReplicationNameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "ddreplicationName")]
        [CacheLookup]
        public IWebElement ReplicationNameDropdown { get; set; }


        [FindsBy(How = How.Id, Using = "div_drp-priority")]
        [CacheLookup]
        public IWebElement PriorityLabel { get; set; }

        [FindsBy(How = How.Id, Using = "chkPair")]
        [CacheLookup]
        public IWebElement Pair { get; set; }

        [FindsBy(How = How.Id, Using = "chkAssociate")]
        [CacheLookup]
        public IWebElement Associate { get; set; }

        [FindsBy(How = How.Id, Using = "ddpairInfraObjectId")]
        [CacheLookup]
        public IWebElement PairInfraObject { get; set; }

        [FindsBy(How = How.Id, Using = "ddpairInfraObjectId")]
        [CacheLookup]
        public IWebElement AssociateInfraObject { get; set; }

        [FindsBy(How = How.Id, Using = "ddpriority")]
        [CacheLookup]
        public IWebElement Priority { get; set; }

        [FindsBy(How = How.Id, Using = "ddprServerId")]
        [CacheLookup]


        public IWebElement ServerDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "ddprReplicationId")]
        [CacheLookup]
        public IWebElement Database { get; set; }

        [FindsBy(How = How.Id, Using = "ddprDatabaseId")]
        [CacheLookup]
        public IWebElement ReplicationDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "chkswitch")]
        [CacheLookup]
        public IWebElement DRReady { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='CreateInfraobjectForm']/fieldset/div/div[1]/div[7]/div/div[2]/label[2]")]
        [CacheLookup]
        public IWebElement NearDR { get; set; }

        //[FindsBy(How = How.Id, Using = "chkswitch")]
        //[CacheLookup]
        // public IWebElement DRReady { get; set; }

        // [FindsBy(How = How.XPath, Using = "chkswitch1")]
        //[CacheLookup]
        //public IWebElement NearDR { get; set; }


        [FindsBy(How = How.Name, Using = "drServerId")]
        [CacheLookup]
        public IWebElement ServerDropdown2 { get; set; }

        [FindsBy(How = How.Id, Using = "dddrReplicationId")]
        [CacheLookup]
        public IWebElement Database2 { get; set; }

        [FindsBy(How = How.Name, Using = "drDatabaseId")]
        [CacheLookup]
        public IWebElement ReplicationDropdown2 { get; set; }


        [FindsBy(How = How.Id, Using = "ddnearDRServerId")]
        [CacheLookup]
        public IWebElement ServerDropdown3 { get; set; }

        [FindsBy(How = How.Id, Using = "ddnearDRReplicationId")]
        [CacheLookup]

        public IWebElement Database3 { get; set; }

        [FindsBy(How = How.Id, Using = "ddnearDRDatabaseId")]
        [CacheLookup]
        public IWebElement ReplicationDropdown3 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='nila-toastr']")]

        public IWebElement SavePopup { get; set; }





        #endregion

        #region Validation

        [FindsBy(How = How.XPath, Using = "//*[@id='CreateInfraobjectForm']/fieldset/div/div[1]/div[1]/span")]
        [CacheLookup]
        public IWebElement InfraObjectNameError { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='CreateInfraobjectForm']/fieldset/div/div[1]/div[2]/span")]
        [CacheLookup]
        public IWebElement DescriptionError { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='CreateInfraobjectForm']/fieldset/div/div[1]/div[3]/span")]
        [CacheLookup]
        public IWebElement BusinessServiceError { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='CreateInfraobjectForm']/fieldset/div/div[1]/div[4]/span")]
        [CacheLookup]
        public IWebElement BusinessFunctionError { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='CreateInfraobjectForm']/fieldset/div/div[1]/div[5]/span")]
        [CacheLookup]
        public IWebElement ActivityTypeError { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='CreateInfraobjectForm']/fieldset/div/div[2]/div[1]/span")]
        [CacheLookup]
        public IWebElement ReplicationTypeError { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='CreateInfraobjectForm']/fieldset/div/div[2]/div[2]/span")]
        [CacheLookup]
        public IWebElement ReplicationNameError { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='CreateInfraobjectForm']/fieldset/div/div[2]/div[4]/span")]
        [CacheLookup]
        public IWebElement PriorityError { get; set; }


        //*[@id="CreateInfraobjectForm"]/fieldset/div/div[1]/div[6]/span
        //*[@id="CreateInfraobjectForm"]/fieldset/div/div[2]/div[4]/span

        //*[@id="CreateInfraobjectForm"]/fieldset/div/div/div/div[2]/span

        [FindsBy(How = How.XPath, Using = " //*[@id='CreateInfraobjectFor']/fieldset/div/div[1]/div[6]/span")]
        [CacheLookup]
        public IWebElement SubtypeError { get; set; }


        [FindsBy(How = How.Id, Using = "btnCloseModal")]
        [CacheLookup]
        public IWebElement CreateClose { get; set; }

        [FindsBy(How = How.Id, Using = "btnSave")]
        [CacheLookup]
        public IWebElement InfraObjectSaveButton { get; set; }

        [FindsBy(How = How.Id, Using = "btn-cancel")]
        [CacheLookup]
        public IWebElement InfraObjectPrevButton { get; set; }

        [FindsBy(How = How.Id, Using = "btn-prev")]
        [CacheLookup]
        public IWebElement InfraObjectPrevButton2 { get; set; }


        [FindsBy(How = How.Id, Using = "btnCancel")]
        [CacheLookup]
        public IWebElement InfraObjectCancelButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[(text()='Next')]")]
        [CacheLookup]
        public IWebElement InfraObjectNextButton1 { get; set; }

        [FindsBy(How = How.Id, Using = "btnNext")]
        [CacheLookup]
        public IWebElement InfraObjectNextButton2 { get; set; }


        [FindsBy(How = How.XPath, Using = "//*[@id='CreateInfraobjectForm']/fieldset/div/div/fieldset/h6[1]/span")]
        [CacheLookup]
        public IWebElement InfraObjectSummaryPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='CreateInfraobjectForm']/fieldset/div/div/div/h6/span")]
        [CacheLookup]
        public IWebElement InfraObjectEstablishPage { get; set; }

        [FindsBy(How = How.Id, Using = "lblName")]
        [CacheLookup]
        public IWebElement InfraObjectcreatepage { get; set; }


        [FindsBy(How = How.XPath, Using = "(//h2[@class='mb-0 text-truncate'])[1]")]
        public IWebElement ActiveCompanies { get; set; }

        public string InfraObjectNameErrorText => InfraObjectNameError.Text;
        public string DescriptionErrorText => DescriptionError.Text;
        public string BusinessServiceErrorText => BusinessServiceError.Text;
        public string BusinessFunctionErrorText => BusinessFunctionError.Text;
        public string ActivityTypeErrorText => ActivityTypeError.Text;
        public string ReplicationTypeErrorText => ReplicationTypeError.Text;
        public string ReplicationNameErrorText => ReplicationNameError.Text;
        public string PriorityErrorText => PriorityError.Text;
        public string SubtypeErrorText => SubtypeError.Text;




        #endregion
        #region methods                             
        public string InfraObjectNameEnter
        {
            set => InfraObjectName.EnterText(value);
        }
        public string DescriptionEnter
        {
            set => DescriptionName.EnterText(value);
        }
        public void SelectBusinessService(string Selectbusinessservice)
        {
            BusinessServiceDropdown.Click();
            Wait();
            BusinessServiceDropdown.SendKeys(Selectbusinessservice);
            BusinessServiceDropdown.SendKeys(Keys.Enter);
        }



        public void SelectBusinessFuction(string Selectbusinessfunction)
        {
            BusinessFunctionDropdown.Click();
            Wait();
            BusinessFunctionDropdown.SendKeys(Selectbusinessfunction);
            BusinessFunctionDropdown.SendKeys(Keys.Enter);
        }
        public void SelectActivityType(string Selectactivitytype)
        {
            ActivityTypeDropdown.Click();
            Wait();
            ActivityTypeDropdown.SendKeys(Selectactivitytype);
            ActivityTypeDropdown.SendKeys(Keys.Enter);
        }
        public void SelectReplicationType(string Selectreplicationtype)
        {
            ReplicationTypeDropdown.Click();
            Wait();
            ReplicationTypeDropdown.SendKeys(Selectreplicationtype);
            ReplicationTypeDropdown.SendKeys(Keys.Enter);
        }

        public void SelectReplicationName(string Selectreplicationname)
        {
            ReplicationNameDropdown.Click();
            Wait();
            ReplicationNameDropdown.SendKeys(Selectreplicationname);
            ReplicationNameDropdown.SendKeys(Keys.Enter);


        }
        public void SelectPriority(string SelectPriority)
        {
            Priority.Click();
            Wait();
            Priority.SendKeys(SelectPriority);
            Priority.SendKeys(Keys.Enter);

        }

        public void SelectServer(string SelectServer)
        {
            ServerDropdown.Click();
            Wait();
            ServerDropdown.SendKeys(SelectServer);
            ServerDropdown.SendKeys(Keys.Enter);

        }

        public void SelectReplication(string SelectReplication)
        {
            ReplicationDropdown.Click();
            Wait();
            ReplicationDropdown.SendKeys(SelectReplication);
            ReplicationDropdown.SendKeys(Keys.Enter);

        }

        public void SelectDatabase(string SelectDatabase)
        {
            Database.Click();
            Wait();
            Database.SendKeys(SelectDatabase);
            Database.SendKeys(Keys.Enter);

        }

        public void SelectServer2(string SelectServer2)
        {
            ServerDropdown2.Click();
            Wait(10000);
            ServerDropdown2.SendKeys(SelectServer2);
            ServerDropdown2.SendKeys(Keys.Enter);

        }

        public void SelectReplication2(string SelectReplication2)
        {
            ReplicationDropdown2.Click();
            Wait(10000);
            ReplicationDropdown2.SendKeys(SelectReplication2);
            ReplicationDropdown2.SendKeys(Keys.Enter);

        }
        public void SelectDatabase2(string SelectDatabase2)
        {
            Database2.Click();
            Wait(10000);
            Database2.SendKeys(SelectDatabase2);
            Database2.SendKeys(Keys.Enter);

        }
        public void SelectServer3(string SelectServer3)
        {
            ServerDropdown3.Click();
            Wait();
            ServerDropdown3.SendKeys(SelectServer3);
            ServerDropdown3.SendKeys(Keys.Enter);

        }
        public void SelectReplication3(string SelectReplication3)
        {
            ReplicationDropdown3.Click();
            Wait(10000);
            ReplicationDropdown3.SendKeys(SelectReplication3);
            ReplicationDropdown3.SendKeys(Keys.Enter);

        }
        public void SelectDatabase3(string SelectDatabase3)
        {
            Database3.Click();
            Wait();
            Database3.SendKeys(SelectDatabase3);
            Database3.SendKeys(Keys.Enter);

        }

        public void SelectPairInfraObjectID(string SelectPairInfraObjectID)
        {
            PairInfraObject.Click();
            Wait();
            PairInfraObject.SendKeys(SelectPairInfraObjectID);
            PairInfraObject.SendKeys(Keys.Enter);
        }

        public void SelecteAssociateInfraObjectID(string SelectAssociateInfraObjectID)
        {
            AssociateInfraObject.Click();
            Wait();
            AssociateInfraObject.SendKeys(SelectAssociateInfraObjectID);
            AssociateInfraObject.SendKeys(Keys.Enter);
        }
        public void SelectSubType(string SelectSubType)
        {
            Subtype.Click();
            Wait();
            Subtype.SendKeys(SelectSubType);
            Subtype.SendKeys(Keys.Enter);

        }




        private static Random random1 = new Random();
        public string RandomString(int len)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz _0123456789";
            return new string(Enumerable.Repeat(chars, len)
              .Select(s => s[random1.Next(64)]).ToArray());
        }

        public void SelectBusinessServiceName(string SelectbusinessserviceName)
        {
            if (SelectbusinessserviceName != "")
            {
                BusinessServiceLabel.Click();

                Wait();

                BusinessServiceDropdown.SendKeys(SelectbusinessserviceName);

                BusinessServiceDropdown.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }

        }

        public void SelectBusinessFunctionName(string SelectbusinessfunctionName)
        {
            if (SelectbusinessfunctionName != "")
            {
                BusinessFunctionLabel.Click();

                Wait();

                BusinessServiceDropdown.SendKeys(SelectbusinessfunctionName);

                BusinessServiceDropdown.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }

        }
        public void SelectActivity_Type(string SelectactivityType)
        {
            if (SelectactivityType != "")
            {
                ActivityLabel.Click();

                Wait();

                BusinessServiceDropdown.SendKeys(SelectactivityType);

                BusinessServiceDropdown.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }

        }
        public void SelectReplication_Type(string SelectreplicationType)
        {
            if (SelectreplicationType != "")
            {
                ReplicationTypeLabel.Click();

                Wait();

                BusinessServiceDropdown.SendKeys(SelectreplicationType);

                BusinessServiceDropdown.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }

        }
        public void SelectReplication_Name(string SelectreplicationName)
        {
            if (SelectreplicationName != "")
            {
                ReplicationNameLabel.Click();

                Wait();

                BusinessServiceDropdown.SendKeys(SelectreplicationName);

                BusinessServiceDropdown.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }

        }
        public void Select_Priority(string SelectrpriorityStatus)
        {
            if (SelectrpriorityStatus != "")
            {
                PriorityLabel.Click();

                Wait();

                BusinessServiceDropdown.SendKeys(SelectrpriorityStatus);

                BusinessServiceDropdown.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }

        }
        public K_Infraobjectpositivetestpage(IWebDriver driver) : base(driver)
        {
            _driver = driver;

            PageFactory.InitElements(_driver, this);
        }

        public static K_Infraobjectpositivetestpage GoTo(IWebDriver driver)
        {
            driver.Navigate().GoToUrl(ConfigHelper.ApplicationPath + "configure/infra_objects");

            return new K_Infraobjectpositivetestpage(driver);
        }

        public K_Infraobjectpositivetestpage Create_two(string randomString1, string randomString2, string selectBusinessService, string selectBusinessFuction, string selectActivityType, string selectReplicationType, string selectReplicationName, string selectPriority, string selectPairInfraobjectID, string selectAssociateInfraObjectID)
        {
            InfraObjectNameEnter = randomString1;
            DescriptionEnter = randomString2;
            SelectBusinessService(selectBusinessService);
            SelectBusinessFuction(selectBusinessFuction);
            SelectActivityType(selectActivityType);
            SelectReplicationType(selectReplicationType);
            SelectReplicationName(selectReplicationName);
            SelectPriority(selectPriority);
            SelectPairInfraObjectID(selectPairInfraobjectID);
            SelecteAssociateInfraObjectID(selectAssociateInfraObjectID);
            return new K_Infraobjectpositivetestpage(_driver);
        }
        public K_Infraobjectpositivetestpage Create_one(string randomString1, string randomString2, string selectBusinessService, string selectBusinessFuction, string selectActivityType, string selectReplicationType, string selectReplicationName, string selectPriority, string selectPairInfraobjectID, string selectAssociateInfraObjectID, string selectSubType)
        {
            InfraObjectNameEnter = randomString1;
            DescriptionEnter = randomString2;
            SelectBusinessService(selectBusinessService);
            SelectBusinessFuction(selectBusinessFuction);
            SelectActivityType(selectActivityType);
            SelectReplicationType(selectReplicationType);
            SelectReplicationName(selectReplicationName);
            SelectPriority(selectPriority);
            SelectSubType(selectSubType);
            return new K_Infraobjectpositivetestpage(_driver);
        }



        public K_Infraobjectpositivetestpage Production(string selectServer, string selectReplication, string selectDatabase)
        {

            SelectServer(selectServer);
            SelectReplication(selectReplication);
            SelectDatabase(selectDatabase);
            return new K_Infraobjectpositivetestpage(_driver);
        }

        public K_Infraobjectpositivetestpage DR(string selectServer, string selectReplication, string selectDatabase)
        {

            SelectServer2(selectServer);
            SelectReplication2(selectReplication);
            SelectDatabase2(selectDatabase);
            return new K_Infraobjectpositivetestpage(_driver);
        }

        public K_Infraobjectpositivetestpage Near_DR(string selectServer, string selectReplication, string selectDatabase)
        {

            SelectServer3(selectServer);
            SelectReplication3(selectReplication);
            SelectDatabase3(selectDatabase);
            return new K_Infraobjectpositivetestpage(_driver);
        }

        public void SaveInfraobject()
        {
            InfraObjectSaveButton.Click();
        }
        public void OpenInfraobject()
        {
            InfraObjectCreateButton.Click();
        }
        public void CloseButton()
        {
            CreateClose.Click();
        }
        public void CancelButton()
        {
            InfraObjectCancelButton.Click();
        }

        public void NextButton()
        {
            InfraObjectNextButton1.Click();
        }

        public void NextButton2()
        {
            InfraObjectNextButton2.Click();
        }
        public void CloseCurrentWindow()
        {
            Driver.Instance.Close();
        }
        public void CloseWindow()
        {
            CreateClose.Click();
        }

        public void PrevButton()
        {
            InfraObjectPrevButton.Click();
        }

        public void PairInfraObjectID()
        {
            Pair.Click();
            PairInfraObject.Click();

        }

        public void Paircheckbox()
        {
            Pair.Click();

        }

        public void AssociateInfraObjectID()
        {
            Associate.Click();
            PairInfraObject.Click();
        }
        #endregion
        public override bool IsAt()
        {
            return Driver.Instance.HasElement(By.XPath("//*[@id='myLargeModalLabel']"));
        }
    }

}











//*[@id="CreateInfraobjectForm"]/fieldset/div/div/div/div[2]/span






