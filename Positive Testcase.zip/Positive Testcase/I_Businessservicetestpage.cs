﻿using ContinuityPatrol.AutomationTests.Extension;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using ContinuityPatrol.AutomationTests.Shared;


namespace ContinuityPatrol.AutomationTests.Pages
{
    public class I_Businessservicetestpage : BasePage
    {
        private readonly IWebDriver _driver;
        #region Fields

        // public IWebElement BusinessServiceCreateButton => _driver.FindElement(By.XPath("//*[@id='layout-wrapper']/div[4]/div/div/div/div/div[1]/div/button"));

        [FindsBy(How = How.XPath, Using = "//*[@id='txtName']")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='btnCreate']")]
        public IWebElement BusinessServiceCreateButton { get; set; }

        [FindsBy(How = How.Id, Using = "txtDescription")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.Id, Using = "ddcompanyId")]
        public IWebElement CompanyLabel { get; set; }

        [FindsBy(How = How.Id, Using = "ddcompanyId")]
        public IWebElement CompanyDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "div_siteId")]
        public IWebElement SiteLabel { get; set; }

        [FindsBy(How = How.Id, Using = "ddsiteId")]

        public IWebElement SiteDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "div_priority")]
        public IWebElement PriorityLabel { get; set; }

        [FindsBy(How = How.Id, Using = "ddpriority")]

        public IWebElement PriorityDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "btnCloseModal")]
        public IWebElement CreateCloseButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnSave")]
        public IWebElement CreateSaveButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement CancelButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='div_siteProperties.PRId']/div/div[1]")]
        public IWebElement dropdowntopology { get; set; }

        [FindsBy(How = How.Id, Using = "ddsiteProperties.PRId")]
        public IWebElement dropdowntopologysite { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='div_siteProperties.DRId']/div/div[1]")]
        public IWebElement topologyDRSite { get; set; }

        [FindsBy(How = How.Id, Using = "ddsiteProperties.DRId")]
        public IWebElement dropdowntopologyDRSite { get; set; }


        [FindsBy(How = How.XPath, Using = "//*[@id='div_siteProperties.NearDrId']/div/div[1]/div[1]")]
        public IWebElement topologyNearDRSite { get; set; }

        [FindsBy(How = How.Id, Using = "ddsiteProperties.NearDrId")]

        public IWebElement dropdowntopologyNearDRSite { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='div_siteProperties.customsiteId']/div/div[2]/div")]
        public IWebElement topologyCustom { get; set; }


        [FindsBy(How = How.Id, Using = "ddsiteProperties.customsiteId")]
        public IWebElement dropdowntopologyCustomSite { get; set; }

        #endregion
        
      
        #region popup

      


        [FindsBy(How = How.XPath, Using = "//div[@id='nila-toastr']")]
        public IWebElement SavePopUp { get; set; }

        #endregion

        #region methods

        public string NameEnter
        {
            set => Name.EnterText(value);
        }

        public string DescriptionEnter
        {
            set => Description.EnterText(value);
        }

        public string CompanyEnter
        {
            set => CompanyDropdown.SendKeys(value);

        }
        public string SiteEnter
        {
            set => SiteDropdown.SendKeys(value);

        }
        public string PriorityEnter
        {
            set => PriorityDropdown.SendKeys(value);

        }

        private static Random random1 = new Random();
        public string RandomString(int len)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz _0123456789";
            return new string(Enumerable.Repeat(chars, len)
              .Select(s => s[random1.Next(64)]).ToArray());
        }
        public void SelectCompanyName(string SelectcompanyName)
        {
            if (SelectcompanyName != "")
            {
                CompanyLabel.Click();
                Wait();
                CompanyDropdown.SendKeys(SelectcompanyName);
                CompanyDropdown.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }
        }

        public void SelectSite(string SelectsiteName)

        {
            if (SelectsiteName != "")
            {
                SiteLabel.Click();
                Wait();
                SiteDropdown.SendKeys(SelectsiteName);
                SiteDropdown.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }
        }
        public void SelectPriority(string Selectpriority)
        {
            if (Selectpriority != "")
            {
                PriorityLabel.Click();
                Wait();
                PriorityDropdown.SendKeys(Selectpriority);
                PriorityDropdown.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }
        }

        public void SelectTopology(string Selecttopologysite1)
        {
            if (Selecttopologysite1 != "")
            {
                dropdowntopology.Click();
                Wait();
                dropdowntopologysite.SendKeys(Selecttopologysite1);
                dropdowntopologysite.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }
        }
        public void SelectTopology1(string Selecttopologysite2)
        {
            if (Selecttopologysite2 != "")
            {
                topologyDRSite.Click();
                Wait();
                dropdowntopologyDRSite.SendKeys(Selecttopologysite2);
                dropdowntopologyDRSite.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }
        }
        public void SelectTopology2(string Selecttopologysite3)
        {
            if (Selecttopologysite3 != "")
            {
                topologyNearDRSite.Click();
                Wait();
                dropdowntopologyNearDRSite.SendKeys(Selecttopologysite3);
                dropdowntopologyNearDRSite.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }
        }
        public void SelectTopology3(string Selecttopologysite4)
        {
            if (Selecttopologysite4 != "")
            {
                topologyCustom.Click();
                Wait();
                dropdowntopologyCustomSite.SendKeys(Selecttopologysite4);
                dropdowntopologyCustomSite.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }
        }


        public I_Businessservicetestpage(IWebDriver driver) : base(driver)
        {
            _driver = driver;

            PageFactory.InitElements(_driver, this);
        }

        public static I_Businessservicetestpage GoTo(IWebDriver driver)
        {
            driver.Navigate().GoToUrl(ConfigHelper.ApplicationPath + "configure/business_service");

            return new I_Businessservicetestpage(driver);
        }
        public I_Businessservicetestpage Create(string randomString1, string randomString2, string companyName, string priority, string selectddtopology, string selectddtopology1, string selectddtopology2)
        {
            NameEnter = randomString1;
            DescriptionEnter = randomString2;
            SelectCompanyName(companyName);
            // SelectSite(siteName);
            SelectPriority(priority);
            SelectTopology(selectddtopology);
            SelectTopology1(selectddtopology1);
            SelectTopology2(selectddtopology2);
            //  SelectTopology3(selectddtopology3);
            return new I_Businessservicetestpage(_driver);
        }
        public void SaveBusinessServiceCreate()
        {
            CreateSaveButton.Click();
        }
        public void OpenBusinessServiceCreate()
        {
            BusinessServiceCreateButton.Click();

        }
        public void BusinessServiceCancel()
        {
            CancelButton.Click();

        }
        public void BusinessServiceClose()
        {
            CreateCloseButton.Click();

        }
        public override bool IsAt()
        {
            return Driver.Instance.HasElement(By.XPath("//*[@id='myLargeModalLabel']"));
        }
    }
}
#endregion
