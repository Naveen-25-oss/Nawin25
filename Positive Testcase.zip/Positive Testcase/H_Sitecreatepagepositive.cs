﻿using ContinuityPatrol.AutomationTests.Extension;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;



namespace ContinuityPatrol.AutomationTests.Pages
{
    public class H_Sitecreatepagepositive : BasePage
    {
        private readonly IWebDriver _driver;

        #region Fields

        [FindsBy(How = How.Id, Using = "btnCreate")]
        [CacheLookup]
        public IWebElement SiteCreateButton { get; set; }

        [FindsBy(How = How.Id, Using = "myLargeModalLabel")]
        [CacheLookup]
        public IWebElement SiteCreateFrame { get; set; }

        [FindsBy(How = How.Id, Using = "txtName")]
        [CacheLookup]
        public IWebElement SiteName { get; set; }

        [FindsBy(How = How.Id, Using = "txtLocation")]
        [CacheLookup]
        public IWebElement SiteLocation { get; set; }

        [FindsBy(How = How.Id, Using = "ddcompanyId")]
        [CacheLookup]
        public IWebElement Company { get; set; }

        [FindsBy(How = How.Id, Using = "div_companyId")]
        [CacheLookup]
        public IWebElement CompanyNameLabel { get; set; }

        //[FindsBy(How = How.Id, Using = "ddcompanyId")]
        //public IWebElement selectCompanyDropdown { get; set; }

        //[FindsBy(How = How.XPath, Using = "//*[@id='ddcompanyId']//child::input")]
        //public IWebElement companyDropdownInput { get; set; }

        [FindsBy(How = How.Id, Using = "lblPhysicalSites_PRSite")]
        [CacheLookup]
        public IWebElement SiteTypePR { get; set; }

        [FindsBy(How = How.Id, Using = "lblchkNearDrs")]

        [CacheLookup]

        public IWebElement SiteTypeNearDR { get; set; }

        [FindsBy(How = How.Id, Using = "lblDrSites")]
        [CacheLookup]
        public IWebElement SiteTypeDR { get; set; }



        //[FindsBy(How = How.Id, Using = "btnCancel")]
        //[CacheLookup]
        //public IWebElement SiteCancelButton { get; set; }

        //public IWebElement SiteCancelButton => _driver.FindElement(By.Id("btnCancel"));


        [FindsBy(How = How.Id, Using = "btnCancel")]
        [CacheLookup]
        public IWebElement SiteCancelButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnSave")]
        [CacheLookup]
        public IWebElement SaveButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnCloseModal")]
        [CacheLookup]
        public IWebElement CreateClose { get; set; }
        #endregion

        #region Validation
        [FindsBy(How = How.XPath, Using = "//*[@id='createSiteForm']/div[1]/span")]
        public IWebElement SiteNameError { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='createSiteForm']/div[2]/span")]

        public IWebElement SiteLocationError { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='createSiteForm']/div[3]/span")]

        public IWebElement SiteCompanyNameError { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[6]/div/div/div[2]/form/div[5]/span")]

        public IWebElement SiteTypeError { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='nila-toastr']")] //nila-toastr

        public IWebElement SiteSavePopup { get; set; }

        [FindsBy(How = How.ClassName, Using = "NoData")]
        public IWebElement NoOption { get; set; }

        [FindsBy(How = How.Id, Using = "ddplatformType")]
        public IWebElement Platformtype { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='createSiteForm']/div[4]/span")]
        public IWebElement PlatformtypeError { get; set; }


        public string SiteNameErrorText => SiteNameError.Text;
        public string SiteLocationErrorText => SiteLocationError.Text;
        public string SiteCompanyNameErrorText => SiteCompanyNameError.Text;
        public string SiteTypeErrorText => SiteTypeError.Text;
        public string SiteCreateFrameText => SiteCreateFrame.Text;
        public string SiteSavePopupText => SiteSavePopup.Text;
        public string NoOptionText => NoOption.Text;
        public string PlatformtypeErrorText => PlatformtypeError.Text;

        #endregion

        #region Methods

        public string SiteNameEnter
        {
            set => SiteName.EnterText(value);
        }
        public string SiteLocationEnter
        {
            set => SiteLocation.EnterText(value);
        }
        public void SelectCompanyName(string companyname)
        {
            if (companyname != "")
            {
                CompanyNameLabel.Click();
                Wait();
                Company.SendKeys(companyname);
                Company.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }
        }

        public void SelectPlatformtype(string selectPlatformtype)
        {
            if (selectPlatformtype != "")
            {
                Platformtype.Click();
                Wait();
                Platformtype.SendKeys(selectPlatformtype);
                Platformtype.SendKeys(Keys.Enter);
            }
            else
            {
                Wait();
            }

        }

        public void SelectSitetype(string selectSitetype)
        {

        }
        private static Random random1 = new Random();
        public string RandomString(int len)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz _0123456789";
            return new string(Enumerable.Repeat(chars, len)
                .Select(s => s[random1.Next(64)]).ToArray());
        }
        public H_Sitecreatepagepositive(IWebDriver driver) : base(driver)
        {
            _driver = driver;
            PageFactory.InitElements(_driver, this);
        }

        public static H_Sitecreatepagepositive GoTo(IWebDriver driver)
        {
            driver.Navigate().GoToUrl(ConfigHelper.ApplicationPath + "Configure/site");
            return new H_Sitecreatepagepositive(driver);
        }


        public H_Sitecreatepagepositive Create(string randomstring1, string randomstring2, string companyname, string selectPlatformtype, string sitetype)
        {
            SiteNameEnter = randomstring1;
            SiteLocationEnter = randomstring2;
            SelectCompanyName(companyname);
            SelectPlatformtype(selectPlatformtype);

            if (sitetype == "PR") { SelectSiteTypePR(); }

            else if (sitetype == "NearDR") { SelectSiteTypeNearDR(); }

            else if (sitetype == "DR") { SelectSiteTypeDR(); }

            //if (selectPlatformtype != null ) { SelectPlatformtype(selectPlatformtype); }
            // if (companyname != null ) { SelectCompanyName(companyname); }
            return new H_Sitecreatepagepositive(_driver);
        }



        public void OpenCreateSite()
        {
            SiteCreateButton.Click();
        }

        public void Cancelsite()
        {
            SiteCancelButton.Click();
        }
        public void CloseCurrentWindow()
        {
            Driver.Instance.Close();
        }

        public void SelectSiteTypePR()
        {
            SiteTypePR.Click();
        }
        public void SelectSiteTypeNearDR()
        {
            SiteTypeNearDR.Click();
        }
        public void SelectSiteTypeDR()
        {
            SiteTypeDR.Click();
        }

        public void SaveSite()
        {
            SaveButton.Click();
        }
        #endregion
        public override bool IsAt()
        {
            return Driver.Instance.HasElement(By.XPath("//*[@id='myLargeModalLabel']"));
        }
    }
}
