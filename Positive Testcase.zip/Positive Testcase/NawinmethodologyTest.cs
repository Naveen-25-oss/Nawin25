﻿using ContinuityPatrol.AutomationTests.Pages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Shouldly;
using ContinuityPatrol.AutomationTests.Shared;
using ContinuityPatrol.AutomationTests.Extension;
using ContinuityPatrol.AutomationTests.Data;
using ContinuityPatrol.AutomationTests.Constants;


namespace ContinuityPatrol.AutomationTests.Tests
{
    [TestClass]
    public class NawinmethodologyTest : BaseTestClass
    {
        private static H_Sitecreatepagepositive _NawinmethodologyTest;

        private static LoginPage _loginPage;

        private string GenerateRandomString(int len) => _NawinmethodologyTest.RandomString(len);


        [ClassInitialize]
        public static void Initialize(TestContext context)
        {
            _loginPage = LoginPage.GoTo(Driver.Instance);
            _loginPage.Login();
            _loginPage.Wait(5000);
            _NawinmethodologyTest = H_Sitecreatepagepositive.GoTo(Driver.Instance);
            _loginPage.Wait();
        }

        [TestInitialize]
        public void TestInitialize()
        {
            if (!_NawinmethodologyTest.IsAt())
            {
                _NawinmethodologyTest.OpenCreateSite();
            }
        }




        [TestMethod]
        [Priority(1)]
        public void Nawinpositivetestsave_InputGiven_Save_Successfully()
        {

            _NawinmethodologyTest.Wait(10);
            _NawinmethodologyTest.IsAt().ShouldBeTrue();
            _NawinmethodologyTest.SiteNameEnter = "PR_Site";
            _NawinmethodologyTest.SiteLocationEnter = "Chennai";
            _NawinmethodologyTest.SelectCompanyName("pts");
            _NawinmethodologyTest.SelectPlatformtype("physical");
           // _NawinmethodologyTest.Create("Site_" + InputConstant.Neardelsite, Any.City, InputConstant.CompanyName, InputConstant.Platformtype, InputConstant.SiteType1);
            _NawinmethodologyTest.Wait(30);
            _NawinmethodologyTest.SaveSite();
        

        }

        [TestMethod]
        [Priority(2)]
        public void Nawinpositivetestsave_InputGiven_Save_Successfully_site2()
        {

            _NawinmethodologyTest.Wait(10);
            _NawinmethodologyTest.IsAt().ShouldBeTrue();
            _NawinmethodologyTest.SiteNameEnter = "DR_Site";
            _NawinmethodologyTest.SiteLocationEnter = "Pune";
            _NawinmethodologyTest.SelectCompanyName("pts");
            _NawinmethodologyTest.SelectPlatformtype("physical");
           // _NawinmethodologyTest.Create("Site_" + InputConstant.Neardelsite, Any.City, InputConstant.CompanyName, InputConstant.Platformtype, InputConstant.SiteType1);
            _NawinmethodologyTest.Wait(30);
            _NawinmethodologyTest.SaveSite();
        }
    }

    [TestClass]
    public class _NawinmethodologyTest : BaseTestClass
    {
        private static I_Businessservicetestpage _NawinmethodologyTest1;

        private static LoginPage _loginPage;



        [ClassInitialize]

        public static void Initialize(TestContext context)
        {
            _loginPage = LoginPage.GoTo(Driver.Instance);
            _loginPage.Login();
            _loginPage.Wait(5000);
            _NawinmethodologyTest1 = I_Businessservicetestpage.GoTo(Driver.Instance);
            _loginPage.Wait();
        }
        [TestInitialize]
        public void TestInitialize()
        {
            if (!_NawinmethodologyTest1.IsAt())
            {
                _NawinmethodologyTest1.OpenBusinessServiceCreate();

            }
        }
        [TestMethod]

        [Priority(3)]
        public void Nawinpositivetestsave_InputGiven_Save_Successfully()
        {
            _NawinmethodologyTest1.IsAt().ShouldBeTrue();
            _NawinmethodologyTest1.Wait();
            _NawinmethodologyTest1.NameEnter = "BS_oracledataguard";
            _NawinmethodologyTest1.DescriptionEnter = "Business service for oracledataguard";
            _NawinmethodologyTest1.SelectCompanyName("pts");
            _NawinmethodologyTest1.SelectPriority("high");
            _NawinmethodologyTest1.SelectTopology("Chennai");
            _NawinmethodologyTest1.SelectTopology1("Pune");
            //_NawinmethodologyTest1.Create(Any.Word(5), Any.String, InputConstant.BusinessServiceCompany, InputConstant.Priority1, InputConstant.businessservicetopology, InputConstant.bstopologyDR, InputConstant.bstopologyneardr);
           // _NawinmethodologyTest1.Wait();
            _NawinmethodologyTest1.SaveBusinessServiceCreate();
        }

        [TestClass]
        public class _NawinmethodologyTest2 : BaseTestClass
        {
            private static J_BusinessFunctioncreatepage _NawinmethodologyTest;

            private static LoginPage _loginPage;


            //private string GenerateRandomString(int len) => _NawinmethodologyTest2.RandomString(len);


            [ClassInitialize]
            public static void Initialize(TestContext context)
            {

                _loginPage = LoginPage.GoTo(Driver.Instance);
                _loginPage.Login();
                _loginPage.Wait(5000);
                _NawinmethodologyTest = J_BusinessFunctioncreatepage.GoTo(Driver.Instance);
                _loginPage.Wait();
            }

            [TestInitialize]
            public void TestInitialize()
            {
                if (!_NawinmethodologyTest.IsAt())
                {
                    _NawinmethodologyTest.OpenCreateBusinessFunction();
                    _NawinmethodologyTest.Wait();
                    _NawinmethodologyTest.IsAtBuinessDetails();

                }

            }

            [TestMethod]
            [Priority(4)]
            public void Nawinpositivetestsave_InputGiven_Save_Successfully()

            {

                _NawinmethodologyTest.IsAt().ShouldBeTrue();
                _NawinmethodologyTest.BusinessFunctionNameEnter = "BF_Oracledataguard";
                _NawinmethodologyTest.DescriptionEnter = "Business Function for oracledataguard";
                _NawinmethodologyTest.SelectBusinessServiceEnter ( "BS_Oracledataguard");
                _NawinmethodologyTest.SelectCriticalLevelEnter("high");
                //_NawinmethodologyTest.CreateBusinessDetails(InputConstant.bussername, Any.String, "Core Banking", "high");
                _NawinmethodologyTest.NextForwardBusinessFunction();
                _NawinmethodologyTest.ConfigureRPOEnter = "22";
                _NawinmethodologyTest.ConfigureRTOEnter = "60";
                _NawinmethodologyTest.ConfigureMAOEnter = "5";
                _NawinmethodologyTest.BusinessFunctionThresholdRpo = "5";
                _NawinmethodologyTest.BusinessFunctionSaveButton.Click();



               // _NawinmethodologyTest.CreateRecoveryObjectives(Any.Number, Any.Number, Any.Number);

            }

        }


        [TestClass]
        public class _NawinmethodologyTest3 : BaseTestClass
        {
            private static FormBiulderCreatePage _formBuilderCreateShould;

            private static LoginPage _loginPage;
            [ClassInitialize]
            public static void Initialize(TestContext context)
            {
                _loginPage = LoginPage.GoTo(Driver.Instance);
                _loginPage.Login();
                _loginPage.Wait(5000);
                _formBuilderCreateShould = FormBiulderCreatePage.GoTo(Driver.Instance);
                _loginPage.Wait();
            }





            [TestInitialize]
            public void TestInitialize()
            {
                if (!_formBuilderCreateShould.IsAt())
                {
                    _formBuilderCreateShould.formCreateButton();
                }
            }



            [TestMethod]
            [Priority(5)]
            public void FormbuilderServer1()
            {
                _formBuilderCreateShould.Create("Linus_Sever", "Server");
                _formBuilderCreateShould.Wait(4000);
                // _formBuilderCreateShould.Password();
                _formBuilderCreateShould.Checkbox1();
                _formBuilderCreateShould.deletecheckboxes.Click();
                _formBuilderCreateShould.deletecheckboxes.Click();
                _formBuilderCreateShould.checkboxclear2.Clear();
                _formBuilderCreateShould.checkboxclear.Clear();
                _formBuilderCreateShould.checkclear = "This is a part of cluster";
                //_formBuilderCreateShould.checkboxclear2.Clear();
                //_formBuilderCreateShould.checkboxclear2.Clear();
                _formBuilderCreateShould.checkboxtext = "✅";
                _formBuilderCreateShould.tickclick();
                _formBuilderCreateShould.Wait(2000);
                _formBuilderCreateShould.DragAndDropExample();
                _formBuilderCreateShould.Wait(1000);
                // _formBuilderCreateShould.textfieldname();
                _formBuilderCreateShould.textfieldnameclear();
                _formBuilderCreateShould.placeclear();
                _formBuilderCreateShould.textenter("IPaddress", "Enter IP Address");
                _formBuilderCreateShould.DragAndDropExample1();
                _formBuilderCreateShould.textfieldnameclear();
                _formBuilderCreateShould.placeclear();
                _formBuilderCreateShould.textenterss("HostName", "Enter HostName");

                _formBuilderCreateShould.Wait();
                _formBuilderCreateShould.tickclick();
                _formBuilderCreateShould.DragAndDropExample234();
                _formBuilderCreateShould.Number.Clear();
                _formBuilderCreateShould.Numberfield = "Port";
                _formBuilderCreateShould.Numberplaceholder.Clear();
                _formBuilderCreateShould.Numberplace = "Enter Port Number";
                _formBuilderCreateShould.Wait(1000);
                //_formBuilderCreateShould.Checkbox1();
                // ✓


                _formBuilderCreateShould.Checkbox1();
                _formBuilderCreateShould.checkbox();
                _formBuilderCreateShould.checkbox();
                _formBuilderCreateShould.checkboxclear2.Clear();
                _formBuilderCreateShould.checkboxclear.Clear();
                _formBuilderCreateShould.checkclear = "Virtual Guest Os";

                _formBuilderCreateShould.checkboxtext = "✅";
                _formBuilderCreateShould.tickclick();
                _formBuilderCreateShould.Dropdown();
                _formBuilderCreateShould.DropdownLabel.Clear();
                _formBuilderCreateShould.checkboxclear2.Clear();
                _formBuilderCreateShould.Dropdownlabel1 = "Authentication Type";
                _formBuilderCreateShould.Dropdownplaceholder.Clear();
                _formBuilderCreateShould.dropdownlabel = "Select AuthenticationType";
                _formBuilderCreateShould.Wait(2000);
                _formBuilderCreateShould.DD = "SShKey";
                _formBuilderCreateShould.FormNameEnter2 = "1";
                _formBuilderCreateShould.DDAdd();
                _formBuilderCreateShould.DD2 = "SSH Password";
                _formBuilderCreateShould.FormNameEnter2 = "2";
                _formBuilderCreateShould.tickclick();
                _formBuilderCreateShould.Heading1();
                _formBuilderCreateShould.Wait(5000);
                // _formBuilderCreateShould.textfieldname();
                _formBuilderCreateShould.placeclear1();
                _formBuilderCreateShould.Numberplace2 = "SSH USER";
                //_formBuilderCreateShould.placeclear3();
                _formBuilderCreateShould.tickclick();
                //_formBuilderCreateShould.placeholder = "Enter SSH User";
                _formBuilderCreateShould.Wait(2000);
                // _formBuilderCreateShould.Numberplace2 = "SSH USER";
                // _formBuilderCreateShould.placeholder = "Enter SSH User";
                _formBuilderCreateShould.Wait(2000);
                _formBuilderCreateShould.Password();
                _formBuilderCreateShould.Formserver2pass.Clear();
                _formBuilderCreateShould.pass = "SSH Password";
                _formBuilderCreateShould.Formserver2pass2.Clear();
                _formBuilderCreateShould.pass2 = "Enter SSHPassword";
                _formBuilderCreateShould.tickclick();
                _formBuilderCreateShould.DragAndDropExample123();
                _formBuilderCreateShould.Wait(2000);
                _formBuilderCreateShould.placeclear4();
                _formBuilderCreateShould.Numberplace23 = "ShellPrompt";
                _formBuilderCreateShould.Checkbox56();
                _formBuilderCreateShould.checkbox3();
                _formBuilderCreateShould.checkbox4();
                _formBuilderCreateShould.checkout1();
                _formBuilderCreateShould.checkout2();
                _formBuilderCreateShould.checkclear23 = "SSO Enabled";
                _formBuilderCreateShould.checkboxtext2 = "✅";
                _formBuilderCreateShould.Wait(2000);
                _formBuilderCreateShould.tickclick();
                _formBuilderCreateShould.Checkbox567();
                _formBuilderCreateShould.checkbox3_1();
                _formBuilderCreateShould.checkbox4_1();
                _formBuilderCreateShould.checkout1_1();
                _formBuilderCreateShould.checkout2_1();
                _formBuilderCreateShould.checkclear23_1 = "IsASMGrid";
                _formBuilderCreateShould.checkboxtext2_1 = "✅";
                _formBuilderCreateShould.Wait(2000);
                _formBuilderCreateShould.tickclick();
               // _formBuilderCreateShould.Wait(2000);
               // _formBuilderCreateShould.Dropdown35();
                //_formBuilderCreateShould.tickclick();
                _formBuilderCreateShould.Wait(3000);
                _formBuilderCreateShould.saveclick();
                _formBuilderCreateShould.fbSavePopUp.Displayed.ShouldBeTrue();


            }
        }


        [TestClass]
        public class FormBuilderTestcase_DBshould : BaseTestClass
        {
            private static Formbuilderpage_DB _FormBuilderTestcase_DBshould;

            private static LoginPage _loginPage;
            [ClassInitialize]
            public static void Initialize(TestContext context)
            {
                _loginPage = LoginPage.GoTo(Driver.Instance);
                _loginPage.Login();
                _loginPage.Wait(5000);
                _FormBuilderTestcase_DBshould = Formbuilderpage_DB.GoTo(Driver.Instance);
                _loginPage.Wait();
            }




            [TestInitialize]
            public void TestInitialize()
            {
                if (!_FormBuilderTestcase_DBshould.IsAt())
                {
                    _FormBuilderTestcase_DBshould.formCreateButton();
                }
            }





            [TestMethod]
            [Priority(6)]
            public void FormbuilderServerDatabase()
            {
                _FormBuilderTestcase_DBshould.Create("Oracle_DB", "Database");
                _FormBuilderTestcase_DBshould.Wait(2000);
                _FormBuilderTestcase_DBshould.Dropdown();
                _FormBuilderTestcase_DBshould.DropdownLabel.Clear();
                _FormBuilderTestcase_DBshould.checkboxclear2.Clear();
                _FormBuilderTestcase_DBshould.Dropdownlabel1 = "Database Version";
                _FormBuilderTestcase_DBshould.Dropdownplaceholder.Clear();
                _FormBuilderTestcase_DBshould.dropdownlabel = "Select Database Version";
                _FormBuilderTestcase_DBshould.Wait(2000);
                _FormBuilderTestcase_DBshould.DD = "9i";
                _FormBuilderTestcase_DBshould.FormNameEnter2 = "1";
                _FormBuilderTestcase_DBshould.DDAdd();
                _FormBuilderTestcase_DBshould.DD2 = "10g";
                _FormBuilderTestcase_DBshould.FormNameEnter2 = "2";
                _FormBuilderTestcase_DBshould.DDAdd();
                _FormBuilderTestcase_DBshould.DD2 = "11g";
                _FormBuilderTestcase_DBshould.FormNameEnter2 = "3";
                _FormBuilderTestcase_DBshould.DDAdd();
                _FormBuilderTestcase_DBshould.DD2 = "12c";
                _FormBuilderTestcase_DBshould.FormNameEnter2 = "4";
                _FormBuilderTestcase_DBshould.DDAdd();
                _FormBuilderTestcase_DBshould.DD2 = "19c";
                _FormBuilderTestcase_DBshould.FormNameEnter2 = "5";
                _FormBuilderTestcase_DBshould.tickclick();
                _FormBuilderTestcase_DBshould.Dropdown2();
                _FormBuilderTestcase_DBshould.tickclick34();
                _FormBuilderTestcase_DBshould.DDAdd23();
                _FormBuilderTestcase_DBshould.Numberfield23 = "Database connectivity";
                _FormBuilderTestcase_DBshould.Wait(3000);
                _FormBuilderTestcase_DBshould.tickclick343();
                _FormBuilderTestcase_DBshould.dropdownlabel2345 = "Select Database connectivity";
                _FormBuilderTestcase_DBshould.Wait(2000);
                _FormBuilderTestcase_DBshould.DD_1 = "Via SSH";
                _FormBuilderTestcase_DBshould.FormNameEnter23_3 = "1";
                _FormBuilderTestcase_DBshould.DDAdd_er();
                _FormBuilderTestcase_DBshould.DD2_2 = "Direct";
                _FormBuilderTestcase_DBshould.FormNameEnter23_2 = "2";
                _FormBuilderTestcase_DBshould.tickclick();
                _FormBuilderTestcase_DBshould.Wait(4000);
                //// _formBuilderCreateShould.Password();
                _FormBuilderTestcase_DBshould.Checkbox1();
                _FormBuilderTestcase_DBshould.deletecheckboxes.Click();
                _FormBuilderTestcase_DBshould.deletecheckboxes.Click();
                _FormBuilderTestcase_DBshould.checkboxclear2.Clear();
                _FormBuilderTestcase_DBshould.checkboxclear.Clear();
                _FormBuilderTestcase_DBshould.checkclear = "This is a part of cluster";
                //_formBuilderCreateShould.checkboxclear2.Clear();
                //_formBuilderCreateShould.checkboxclear2.Clear();
                _FormBuilderTestcase_DBshould.checkboxtext = "✅";
                _FormBuilderTestcase_DBshould.tickclick();
                _FormBuilderTestcase_DBshould.Wait(2000);
                _FormBuilderTestcase_DBshould.DragAndDropExample();
                _FormBuilderTestcase_DBshould.Wait(1000);
                // _formBuilderCreateShould.textfieldname();
                _FormBuilderTestcase_DBshould.textfieldnameclear();
                _FormBuilderTestcase_DBshould.placeclear();
                _FormBuilderTestcase_DBshould.textenter("Oracle SID", "Enter Oracle SID");
                _FormBuilderTestcase_DBshould.tickclick();
                _FormBuilderTestcase_DBshould.DragAndDropExample1();
                _FormBuilderTestcase_DBshould.textfieldnameclear_90();
                _FormBuilderTestcase_DBshould.ExepathNameEnter_09 = "Instance Name";
                _FormBuilderTestcase_DBshould.placeclear_09();
                _FormBuilderTestcase_DBshould.placeholder_908 = "Enter Instance Name";
                _FormBuilderTestcase_DBshould.Wait();
                _FormBuilderTestcase_DBshould.tickclick();
                _FormBuilderTestcase_DBshould.Checkbox1();
                _FormBuilderTestcase_DBshould.checkbox();
                _FormBuilderTestcase_DBshould.checkbox();
                _FormBuilderTestcase_DBshould.checkboxclear2.Clear();
                _FormBuilderTestcase_DBshould.checkboxclear.Clear();
                _FormBuilderTestcase_DBshould.checkclear = "SSO Enabled";
                _FormBuilderTestcase_DBshould.checkboxtext = "✅";
                _FormBuilderTestcase_DBshould.tickclick();
                //_FormBuilderTestcase_DBshould.DragAndDropExample234();
                _FormBuilderTestcase_DBshould.Heading1();
                _FormBuilderTestcase_DBshould.Wait(5000);
                // _formBuilderCreateShould.textfieldname();
                _FormBuilderTestcase_DBshould.placeclear1();
                _FormBuilderTestcase_DBshould.Numberplace2 = "Username";
                //_formBuilderCreateShould.placeclear3();
                _FormBuilderTestcase_DBshould.tickclick();
                _FormBuilderTestcase_DBshould.Password();
                _FormBuilderTestcase_DBshould.Formserver2pass.Clear();
                _FormBuilderTestcase_DBshould.pass = "Password";
                _FormBuilderTestcase_DBshould.Formserver2pass2.Clear();
                _FormBuilderTestcase_DBshould.pass2 = "Enter Password";
                _FormBuilderTestcase_DBshould.tickclick();
                _FormBuilderTestcase_DBshould.DragAndDropExample234();
                _FormBuilderTestcase_DBshould.Number.Clear();
                _FormBuilderTestcase_DBshould.Numberfield = "Port";
                _FormBuilderTestcase_DBshould.Numberplaceholder.Clear();
                _FormBuilderTestcase_DBshould.Numberplace = "Enter Port Number";
                _FormBuilderTestcase_DBshould.Wait(1000);
                _FormBuilderTestcase_DBshould.tickclick();
                _FormBuilderTestcase_DBshould.DragAndDropExample123();
                _FormBuilderTestcase_DBshould.Wait(2000);
                _FormBuilderTestcase_DBshould.placeclear4();
                _FormBuilderTestcase_DBshould.Numberplace23 = "Archive Path";
                _FormBuilderTestcase_DBshould.placeclear_092();
                _FormBuilderTestcase_DBshould.placeholder_90890 = "Enter Archive Path";
                _FormBuilderTestcase_DBshould.tickclick();
                _FormBuilderTestcase_DBshould.DragAndDropExample123();
                _FormBuilderTestcase_DBshould.placeclear4_23();
                _FormBuilderTestcase_DBshould.Numberplace23_09 = "Oracle HomePath";
                _FormBuilderTestcase_DBshould.placeclear_092_01();
                _FormBuilderTestcase_DBshould.placeholder_90890_09 = "Enter Oracle HomePath";
                _FormBuilderTestcase_DBshould.tickclick();
                _FormBuilderTestcase_DBshould.Wait(2000);
                _FormBuilderTestcase_DBshould.saveclick();
                _FormBuilderTestcase_DBshould.fbSavePopUp.Displayed.ShouldBeTrue();





















            }
















        }

        [TestClass]
        public class I01_09_FormBuilderTestcase_Repshould : BaseTestClass
        {
            private static Formbuilderpage_DB _FormBuilderTestcase_Repshould;

            private static LoginPage _loginPage;
            [ClassInitialize]
            public static void Initialize(TestContext context)
            {
                _loginPage = LoginPage.GoTo(Driver.Instance);
                _loginPage.Login();
                _loginPage.Wait(5000);
                _FormBuilderTestcase_Repshould = Formbuilderpage_DB.GoTo(Driver.Instance);
                _loginPage.Wait();
            }




            [TestInitialize]
            public void TestInitialize()
            {
                if (!_FormBuilderTestcase_Repshould.IsAt())
                {
                    _FormBuilderTestcase_Repshould.formCreateButton();
                }
            }





            [TestMethod]
            [Priority(7)]
            public void FormbuilderServerReplication()
            {
                _FormBuilderTestcase_Repshould.Create("Native Replication_Oracle_Dataguard", "Replication");
                _FormBuilderTestcase_Repshould.Wait(2000);
                _FormBuilderTestcase_Repshould.Dropdown();
                _FormBuilderTestcase_Repshould.DropdownLabel.Clear();
                _FormBuilderTestcase_Repshould.checkboxclear2.Clear();
                _FormBuilderTestcase_Repshould.Dropdownlabel1 = "Replication Mode";
                _FormBuilderTestcase_Repshould.Dropdownplaceholder.Clear();
                _FormBuilderTestcase_Repshould.dropdownlabel = "Select Replication Mode";
                _FormBuilderTestcase_Repshould.Wait(2000);
                _FormBuilderTestcase_Repshould.DD = "Sync";
                _FormBuilderTestcase_Repshould.FormNameEnter2 = "1";
                _FormBuilderTestcase_Repshould.DDAdd();
                _FormBuilderTestcase_Repshould.DD2 = "Async";
                _FormBuilderTestcase_Repshould.FormNameEnter2 = "2";
                _FormBuilderTestcase_Repshould.tickclick();
                _FormBuilderTestcase_Repshould.DragAndDropExample123();
                _FormBuilderTestcase_Repshould.placeclear4_23();
                _FormBuilderTestcase_Repshould.Numberplace23_09 = "Service Name";
                _FormBuilderTestcase_Repshould.placeclear_092_01();
                _FormBuilderTestcase_Repshould.placeholder_90890_09 = "Enter Service Name";
                _FormBuilderTestcase_Repshould.tickclick();
                _FormBuilderTestcase_Repshould.Dropdown2();
                _FormBuilderTestcase_Repshould.DDAdd23();
                _FormBuilderTestcase_Repshould.Numberfield23 = "Protection Mode";
                _FormBuilderTestcase_Repshould.Wait(3000);
                _FormBuilderTestcase_Repshould.tickclick343();
                _FormBuilderTestcase_Repshould.dropdownlabel2345 = "Select Protection Mode";
                _FormBuilderTestcase_Repshould.Wait(2000);
                _FormBuilderTestcase_Repshould.DD_1 = "Maximum Availability";
                _FormBuilderTestcase_Repshould.FormNameEnter23_3 = "1";
                _FormBuilderTestcase_Repshould.DDAdd_er();
                _FormBuilderTestcase_Repshould.DD2_2 = "Maximum Performance";
                _FormBuilderTestcase_Repshould.FormNameEnter23_2 = "2";
                _FormBuilderTestcase_Repshould.DDAdd_er();
                _FormBuilderTestcase_Repshould.DD_1 = "Maximum Protection";
                _FormBuilderTestcase_Repshould.FormNameEnter23_3 = "3";

                _FormBuilderTestcase_Repshould.tickclick();
                _FormBuilderTestcase_Repshould.saveclick();
                _FormBuilderTestcase_Repshould.fbSavePopUp.Displayed.ShouldBeTrue();


















            }
        }

        [TestClass]
        public class A01_05_Infraobjectpositivetestcaseshould : BaseTestClass
        {
            private static K_Infraobjectpositivetestpage _Infraobjectpositivetestcase;

            private static LoginPage _loginPage;
            private string GenerateRandomString(int len) => _Infraobjectpositivetestcase.RandomString(len);

            [ClassInitialize]

            public static void Initialize(TestContext context)
            {

                _loginPage = LoginPage.GoTo(Driver.Instance);
                _loginPage.Login();
                _loginPage.Wait(5000);
                _Infraobjectpositivetestcase = K_Infraobjectpositivetestpage.GoTo(Driver.Instance);
                _loginPage.Wait();
            }


            [TestInitialize]

            public void TestInitialize()
            {
                if (!_Infraobjectpositivetestcase.IsAt())
                {
                    _Infraobjectpositivetestcase.OpenInfraobject();
                }

            }





            [TestMethod]
            [Priority(7)]
            public void Nawinpositivetestsave_InputGiven_Save_Successfully()
            {
                _Infraobjectpositivetestcase.IsAt().ShouldBeTrue();
                _Infraobjectpositivetestcase.InfraObjectNameEnter = "ODG_Infra";
                _Infraobjectpositivetestcase.DescriptionEnter = "ODG_InfraSwitchover";
                _Infraobjectpositivetestcase.SelectBusinessService("BS_oracledataguard");
                _Infraobjectpositivetestcase.SelectBusinessFuction("BF_ODG");
                _Infraobjectpositivetestcase.SelectActivityType("DB");
                _Infraobjectpositivetestcase.SelectSubType("Database-Native Replication");
                _Infraobjectpositivetestcase.DRReady.Click();
                _Infraobjectpositivetestcase.SelectReplicationType("NativeReplication_ODG");
                _Infraobjectpositivetestcase.SelectReplicationName("ODG19CPR_Replication");
                _Infraobjectpositivetestcase.SelectPriority("high");
                //_Infraobjectpositivetestcase.Create_one(Any.Word(5), Any.Word(5), InputConstant.Service, InputConstant.Function, InputConstant.ActivityType2, InputConstant.ReplicationType, InputConstant.ReplicationName, InputConstant.PriorityC, InputConstant.PairInfraObjectID, InputConstant.AssociateInfraObjectID, InputConstant.SubType);
                _Infraobjectpositivetestcase.NextButton();
                _Infraobjectpositivetestcase.SelectServer("PR_ODG_Server_175");
                _Infraobjectpositivetestcase.SelectDatabase("PR_ODG_DB_175");
                _Infraobjectpositivetestcase.SelectReplication("ODG19CPR_Replication");
                _Infraobjectpositivetestcase.SelectServer2("DR_ODG_Server_176");
                _Infraobjectpositivetestcase.SelectDatabase2("DR_ODG_DB_175");
                _Infraobjectpositivetestcase.SelectReplication2("ODG19CPR_Replication");
                //_Infraobjectpositivetestcase.Production(InputConstant.Server2, InputConstant.Database, InputConstant.Replication2);
                _Infraobjectpositivetestcase.NextButton2();
                //_Infraobjectpositivetestcase.Wait(2000);
                //_Infraobjectpositivetestcase.SaveInfraobject();
                //_Infraobjectpositivetestcase.Wait(2000);
                //_Infraobjectpositivetestcase.SavePopup.Displayed.ShouldBeTrue();

            }


        }
    }
}

























