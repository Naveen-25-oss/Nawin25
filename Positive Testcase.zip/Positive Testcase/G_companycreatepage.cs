﻿using ContinuityPatrol.AutomationTests.Extension;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using ContinuityPatrol.AutomationTests.Shared;


namespace ContinuityPatrol.AutomationTests.Pages
{
    public class Continuitypatrolpositivetestcasepage : BasePage
    {
        private readonly IWebDriver _driver;

        #region Fields

        [FindsBy(How = How.Id, Using = "btnCreate")]
        [CacheLookup]
        public IWebElement CompanyCreateButton { get; set; }



        [FindsBy(How = How.Id, Using = "txtName")]
        [CacheLookup]
        public IWebElement CompanyName { get; set; }


        [FindsBy(How = How.Id, Using = "txtdisplayName")]
        [CacheLookup]
        public IWebElement Displayname { get; set; }

        [FindsBy(How = How.Id, Using = "txtwebAddress")]
        [CacheLookup]
        public IWebElement webaddress { get; set; }




        [FindsBy(How = How.Id, Using = "btnSave")]
        [CacheLookup]
        public IWebElement companySaveButton { get; set; }

        [FindsBy(How = How.Id, Using = "txtName")]
        [CacheLookup]
        public IWebElement Sitenamebutton { get; set; }

        [FindsBy(How = How.Id, Using = "txtLocation")]
        [CacheLookup]
        public IWebElement Location { get; set; }


        [FindsBy(How = How.Id, Using = "ddcompanyId")]
        [CacheLookup]
        public IWebElement Companysite { get; set; }

        [FindsBy(How = How.Id, Using = "ddplatformType")]
        public IWebElement Platformtype { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='lblPrSites']")]









        #endregion


        #region Popup validation

        [FindsBy(How = How.Id, Using = "nila-toastr")]
        public IWebElement companySavePopUp { get; set; }

        #endregion

        #region Methods

        public string CompanyNameEnter
        {
            set => CompanyName.EnterText(value);
        }

        public string DisplayCompanyNameEnter
        {
            set => Displayname.EnterText(value);
        }

        public string WebaddressEnter
        {
            set => webaddress.EnterText(value);
        }





        private static Random random1 = new Random();
        public string RandomString(int len)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz _0123456789";
            return new string(Enumerable.Repeat(chars, len)
              .Select(s => s[random1.Next(64)]).ToArray());
        }

        public Continuitypatrolpositivetestcasepage(IWebDriver driver) : base(driver)
        {
            _driver = driver;

            PageFactory.InitElements(_driver, this);

        }
        public static Continuitypatrolpositivetestcasepage GoTo(IWebDriver driver)
        {
            driver.Navigate().GoToUrl(ConfigHelper.ApplicationPath + "configure/company");
            //driver.Navigate().GoToUrl(ConfigHelper.ApplicationPath + "configure/site");





            return new Continuitypatrolpositivetestcasepage(driver);
        }

        //public static Continuitypatrolpositivetestcasepage (IWebDriver Sitenavigate)
        //{
        //    driver.Navigate().GoToUrl(ConfigHelper.ApplicationPath + "configure/company");

        //    return new Continuitypatrolpositivetestcasepage(Sitenavigate);
        //}





        public void ScrollActionToElement(IWebElement element)
        {
            Actions actions = new Actions(_driver);
            actions.MoveToElement(element);
            actions.Perform();
        }
        public Continuitypatrolpositivetestcasepage CreateDetails(string randomString1, string randomString2, string randomString3)
        {
            CompanyNameEnter = randomString1;
            DisplayCompanyNameEnter = randomString2;
            WebaddressEnter = randomString3;



            return new Continuitypatrolpositivetestcasepage(_driver);
        }





        //static void Main multiplepage(string[] args)
        //{

        //    IWebDriver driver = new ChromeDriver();


        //    driver.Navigate().GoToUrl("https://www.example.com/page1");




        //    driver.Navigate().GoToUrl("https://www.example.com/page2");




        //    driver.Navigate().GoToUrl("https://www.example.com/page3");



        public void companySave()
        {
            companySaveButton.Click();
        }

        public void Companycreate()
        {
            CompanyCreateButton.Click();
        }

        #endregion

        public override bool IsAt()
        {
            return Driver.Instance.HasElement(By.XPath("//*[@id='myLargeModalLabel']"));

        }

        //private static void Sitenavigate()
        //{
        //   var site = driver.Navigate().GoToUrl("https://www.example.com/page3");

        //}

        //string[] pageUrls = { "configure/site", "configure/business_service", "configure/business_function" };
        //url1=string[0]

      
        





    }
}

